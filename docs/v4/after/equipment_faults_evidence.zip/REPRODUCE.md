# Reproducing this evidence

Evidence format: brace-embrace/0.7.1-design3. Extract the ZIP and open research_summary.html without
a server or network. Input hashes, methods and output tables are enclosed.
Original uploaded files are excluded. Obtain the matching originals separately
and verify their SHA-256; this package alone cannot recreate private inputs.
Use the matching BRACE source and dependency versions in analysis_methods.json.
CSV_TEXT_ENCODING.json records reversible spreadsheet-safe text encoding.
Run configuration and declared evaluation role must match; declarations do not
authenticate acquisition or observation independence.

Evaluate the same labeled prediction records and class/column declaration:
python -m brace_core.stage06_cli evaluate --predictions ORIGINAL.csv --manifest ORIGINAL_MANIFEST.json --out NEW_DIRECTORY

This evaluates supplied predictions; it does not execute or retrain their model.

Where computed, uncertainty uses saved Wilson intervals and a1000-replicate
class-stratified row bootstrap, seed20261101. These assume independent rows and
do not correct unknown group/batch dependence. Confidence>=cutoff retains equal
values; a nonreference cutoff viewed after outcomes is exploratory.
Compare numerical artifacts. Software-version changes and random run IDs can
change provenance hashes without changing numerical results. Repeated export of
an unchanged run/version is byte-stable. Verify FILE_SHA256_MANIFEST.csv and
the published-byte hashes, separate from original scientific-source hashes.
