# Reproducing this evidence

Evidence format: brace-embrace/0.6.0. Open research_summary.html in a browser with no
server or network. Machine-readable CSV/JSON, methods, compatibility, warnings,
input hashes and output hashes are enclosed. Raw uploads are deliberately absent.

Use the matching BRACE source checkpoint and Python dependencies recorded in
analysis_methods.json. Obtain the original inputs separately with the listed
SHA-256 hashes. Acquisition/independence declarations are not authenticated.
Consult CSV_TEXT_ENCODING.json before matching text identifiers from CSV to JSON.

Analysis mode: race. Preserve source/target roles, exact processing/labels and recorded settings.

RACE: parse the six named input files with brace_core.intake.parse_cohort, then
call brace_core.signature.run(source, target, JSON contents of race_config.json,
a new output directory). The saved source-only rule screens the full source
family and freezes selected IDs before target testing. Do not choose genes from
target results. For the approved public pair, see its preparation README in the
BRACE checkpoint: GEO GSE42568 source and GSE20711 target, ER-positive minus
ER-negative tumors. Do not substitute raw counts or differently processed data.

Mode A: python -m brace_core.stage06_cli evaluate --predictions ORIGINAL.csv
--manifest ORIGINAL_MANIFEST.json --out NEW_DIRECTORY (one command line).

Mode B: python -m brace_core.stage06_cli train with --source-expression,
--source-metadata, --source-manifest, --target-expression, --target-metadata,
--target-manifest and --out pointing to matching originals/a new directory.
Default binary classes are normal/tumor. Source fold seed 42 and the full frozen
configuration are recorded; never refit scaling or choose settings using target
outcomes. Source CV and target scoring have different evaluation designs.

Mode C: python -m brace_core.stage07_cli with the same six cohort arguments,
--mode diagnose_shift and --out NEW_DIRECTORY. Outcome labels remain excluded;
no target accuracy or class-conditioned diagnostic is produced.

Stage 06 uncertainty uses saved Wilson intervals and a 1,000-replicate
class-stratified row bootstrap with seed 20261101 where support permits. These
assume independent rows and do not account for unknown patient/study clustering.
Threshold curves use confidence >= cutoff; non-reference choices are post hoc.

Compare numerical scientific artifacts across reruns. New random run IDs and
their provenance/report text may differ without numerical nondeterminism.
Each completed-run ZIP is byte-stable across repeated downloads; ZIP entry times
are fixed. Verify every FILE_SHA256_MANIFEST.csv entry and the JSON output hashes.
Do not mistake hashes for independent authentication of biological provenance.
